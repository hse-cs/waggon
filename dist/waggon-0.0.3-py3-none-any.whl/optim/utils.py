import numpy as np

PRIMES = np.array([2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97])

def get_olhs_num(n):
    return PRIMES[PRIMES ** 2 > n]**2