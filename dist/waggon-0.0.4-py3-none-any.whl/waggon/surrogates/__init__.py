from .gan import WGAN_GP as GAN

__all__ = [
    'GAN'
]